MOCA Bitcoin flutter package for HD wallet and Bitcoin operations.

## Functions

1) generateMnemonic
2) getPublicKey
3) getPrivateKey
4) getAddress
5) sign
6) verify
7) getBalance
8) sendTransaction - soon!

## Additional information

This package is currenly on development phase, we dont reccomend to use it on live project.
