///
//  Generated code. Do not modify.
//  source: cosmos/slashing/v1beta1/tx.proto
//
// @dart = 2.12
// ignore_for_file: annotate_overrides,camel_case_types,constant_identifier_names,deprecated_member_use_from_same_package,directives_ordering,library_prefixes,non_constant_identifier_names,prefer_final_fields,return_of_invalid_type,unnecessary_const,unnecessary_import,unnecessary_this,unused_import,unused_shown_name

import 'dart:core' as $core;
import 'dart:convert' as $convert;
import 'dart:typed_data' as $typed_data;
@$core.Deprecated('Use msgUnjailDescriptor instead')
const MsgUnjail$json = const {
  '1': 'MsgUnjail',
  '2': const [
    const {'1': 'validator_addr', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'validatorAddr'},
  ],
  '7': const {},
};

/// Descriptor for `MsgUnjail`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List msgUnjailDescriptor = $convert.base64Decode('CglNc2dVbmphaWwSRAoOdmFsaWRhdG9yX2FkZHIYASABKAlCHfLeHw55YW1sOiJhZGRyZXNzIureHwdhZGRyZXNzUg12YWxpZGF0b3JBZGRyOgiIoB8AmKAfAQ==');
@$core.Deprecated('Use msgUnjailResponseDescriptor instead')
const MsgUnjailResponse$json = const {
  '1': 'MsgUnjailResponse',
};

/// Descriptor for `MsgUnjailResponse`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List msgUnjailResponseDescriptor = $convert.base64Decode('ChFNc2dVbmphaWxSZXNwb25zZQ==');
