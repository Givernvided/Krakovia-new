///
//  Generated code. Do not modify.
//  source: cosmos/base/store/v1beta1/listening.proto
//
// @dart = 2.12
// ignore_for_file: annotate_overrides,camel_case_types,constant_identifier_names,deprecated_member_use_from_same_package,directives_ordering,library_prefixes,non_constant_identifier_names,prefer_final_fields,return_of_invalid_type,unnecessary_const,unnecessary_import,unnecessary_this,unused_import,unused_shown_name

import 'dart:core' as $core;
import 'dart:convert' as $convert;
import 'dart:typed_data' as $typed_data;
@$core.Deprecated('Use storeKVPairDescriptor instead')
const StoreKVPair$json = const {
  '1': 'StoreKVPair',
  '2': const [
    const {'1': 'store_key', '3': 1, '4': 1, '5': 9, '10': 'storeKey'},
    const {'1': 'delete', '3': 2, '4': 1, '5': 8, '10': 'delete'},
    const {'1': 'key', '3': 3, '4': 1, '5': 12, '10': 'key'},
    const {'1': 'value', '3': 4, '4': 1, '5': 12, '10': 'value'},
  ],
};

/// Descriptor for `StoreKVPair`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List storeKVPairDescriptor = $convert.base64Decode('CgtTdG9yZUtWUGFpchIbCglzdG9yZV9rZXkYASABKAlSCHN0b3JlS2V5EhYKBmRlbGV0ZRgCIAEoCFIGZGVsZXRlEhAKA2tleRgDIAEoDFIDa2V5EhQKBXZhbHVlGAQgASgMUgV2YWx1ZQ==');
