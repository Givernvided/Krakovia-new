///
import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;
@$core.Deprecated('Use equivocationDescriptor instead')
const Equivocation$json = const {
  '1': 'Equivocation',
  '2': const [
    const {'1': 'height', '3': 1, '4': 1, '5': 3, '10': 'height'},
    const {'1': 'time', '3': 2, '4': 1, '5': 11, '6': '.google.protobuf.Timestamp', '8': const {}, '10': 'time'},
    const {'1': 'power', '3': 3, '4': 1, '5': 3, '10': 'power'},
    const {'1': 'consensus_address', '3': 4, '4': 1, '5': 9, '8': const {}, '10': 'consensusAddress'},
  ],
  '7': const {},
};

/// Descriptor for `Equivocation`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List equivocationDescriptor = $convert.base64Decode('CgxFcXVpdm9jYXRpb24SFgoGaGVpZ2h0GAEgASgDUgZoZWlnaHQSOAoEdGltZRgCIAEoCzIaLmdvb2dsZS5wcm90b2J1Zi5UaW1lc3RhbXBCCMjeHwCQ3x8BUgR0aW1lEhQKBXBvd2VyGAMgASgDUgVwb3dlchJJChFjb25zZW5zdXNfYWRkcmVzcxgEIAEoCUIc8t4fGHlhbWw6ImNvbnNlbnN1c19hZGRyZXNzIlIQY29uc2Vuc3VzQWRkcmVzczoMmKAfAIigHwDooB8A');
